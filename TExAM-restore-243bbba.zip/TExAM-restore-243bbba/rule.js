function next() {
    window.location.href = "countdown.html";
}
